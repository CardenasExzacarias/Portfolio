<?php
const saName = 'NIVEL DE ADAPTACION SOCIAL';
const saStyle = "10em auto auto";
const saColumns = [
    'Categoría',
    '%',
    'Rango'
];
const category = [
    'Habilidad de supervisión',
    'Capacidad de decisión en las relaciones humanas',
    'Capacidad de evaluación de problemas interpersonales',
    'Habilidad para establecer relaciones interpersonales',
    'Sentido común y tacto en las relaciones interpersonales'
];
const jsName = 'NIVEL DE JUICIO SOCIAL';
const jsStyle = "repeat(2, 10em)";
const jsColumns = [
    'Número de respuestas',
    'Rango'
];
const columns = 10;
const width = '2.8em';