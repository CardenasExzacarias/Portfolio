<?php
const name = "RESULTADOS";
const columns = [
    'Puntuación Directa',
    'Coeficiente Intelectual',
    'Rango',
    'Dx'
];
const style = "repeat(4, auto)";

const column = 10;
const width = "auto";