<?php
const name = 'RESULTADO';
const style = "repeat(2, 10em)";
const columns = ['Personalidad', '%'];
const scales = [
    'Evitación',
    'Dependiente',
    'Obsesivo',
    'Pasivo-Agresivo',
    'Pasivo-Dependiente',
    'Paranoide',
    'Esquizotípico',
    'Esquizoide',
    'Histriónico',
    'Narcisista',
    'Límite',
    'Antisocial'
];
const answerColumns = 12;
const answersWidth = '3.4em';